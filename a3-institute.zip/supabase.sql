-- CHUO CONNECT: Supabase (Postgres) schema + RLS. Run in SQL Editor.
create extension if not exists pgcrypto;

create type user_role as enum ('student','teacher','admin');
create type leave_status as enum ('pending','approved','rejected');

create table courses(id serial primary key, name text unique not null);
insert into courses(name) values ('Radiology'),('Nursing'),('Pharmacy'),('Journalism') on conflict do nothing;

create table profiles(
  id uuid primary key references auth.users on delete cascade,
  full_name text not null check (length(full_name) between 2 and 100),
  phone text check (phone ~ '^[0-9+]{9,15}$'),
  role user_role not null default 'student',
  course_id int references courses(id),
  created_at timestamptz default now());

-- Helper functions (security definer = avoid RLS recursion)
create function public.my_role() returns user_role language sql stable security definer set search_path=public as
$$ select role from profiles where id = auth.uid() $$;
create function public.my_course() returns int language sql stable security definer set search_path=public as
$$ select course_id from profiles where id = auth.uid() $$;
create function public.is_staff() returns boolean language sql stable as
$$ select public.my_role() in ('teacher','admin') $$;

-- New user: ALWAYS student. Teachers are promoted by admin only.
create function public.on_signup() returns trigger language plpgsql security definer set search_path=public as
$$ begin insert into profiles(id,full_name,phone,course_id)
  values(new.id, coalesce(new.raw_user_meta_data->>'full_name','Mwanafunzi'), new.raw_user_meta_data->>'phone',
  nullif(new.raw_user_meta_data->>'course_id','')::int); return new; end $$;
create trigger t_signup after insert on auth.users for each row execute function public.on_signup();

-- Block self-promotion
create function public.lock_role() returns trigger language plpgsql as
$$ begin if new.role<>old.role and coalesce(public.my_role(),'admin')<>'admin' then
  raise exception 'Huruhusiwi kubadili role'; end if; return new; end $$;
create trigger t_lock before update on profiles for each row execute function public.lock_role();

create table timetable(id bigserial primary key, course_id int not null references courses(id),
  day smallint not null check (day between 1 and 6), start_time time not null, subject text not null, room text,
  created_by uuid default auth.uid() references profiles(id));
create table notes(id bigserial primary key, course_id int not null references courses(id), subject text,
  title text not null, body text, file_path text, created_by uuid default auth.uid() references profiles(id), created_at timestamptz default now());
create table notices(id bigserial primary key, course_id int references courses(id), -- null = wote
  title text not null, body text not null, created_by uuid default auth.uid() references profiles(id), created_at timestamptz default now());
create table attendance(id bigserial primary key, student_id uuid not null references profiles(id), course_id int not null references courses(id),
  subject text not null, class_date date not null, present boolean not null, marked_by uuid default auth.uid() references profiles(id),
  unique(student_id, subject, class_date));
create table ideas(id bigserial primary key, student_id uuid default auth.uid() references profiles(id), course_id int references courses(id),
  body text not null check (length(body) between 3 and 2000), anonymous boolean default false, created_at timestamptz default now());
create table leave_requests(id bigserial primary key, student_id uuid default auth.uid() not null references profiles(id), reason text not null,
  date_from date not null, date_to date not null check (date_to>=date_from), status leave_status default 'pending',
  decided_by uuid references profiles(id), created_at timestamptz default now());
create table whatsapp_groups(course_id int primary key references courses(id),
  invite_url text not null check (invite_url ~ '^https://chat\.whatsapp\.com/'));
create table audit_log(id bigserial primary key, actor uuid, action text, tbl text, row_id text, at timestamptz default now());

create index on timetable(course_id); create index on notes(course_id); create index on notices(course_id);
create index on attendance(student_id, course_id); create index on leave_requests(student_id, status);

-- Students may only change the status of NOTHING in leave_requests; staff decide
create function public.audit() returns trigger language plpgsql security definer set search_path=public as
$$ begin insert into audit_log(actor,action,tbl,row_id) values(auth.uid(),tg_op,tg_table_name,coalesce(new.id::text,old.id::text)); return coalesce(new,old); end $$;
create trigger a1 after insert or update or delete on attendance for each row execute function public.audit();
create trigger a2 after update or delete on leave_requests for each row execute function public.audit();
create trigger a3 after delete on notes for each row execute function public.audit();

-- ROW LEVEL SECURITY: enable on EVERYTHING
do $$ declare t text; begin
 foreach t in array array['courses','profiles','timetable','notes','notices','attendance','ideas','leave_requests','whatsapp_groups','audit_log']
 loop execute format('alter table %I enable row level security', t); end loop; end $$;

create policy c_r on courses for select to authenticated using (true);
create policy p_r on profiles for select to authenticated using (id=auth.uid() or public.is_staff());
create policy p_u on profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());

-- Course content: students see own course; staff manage
create policy tt_r on timetable for select to authenticated using (course_id=public.my_course() or public.is_staff());
create policy tt_w on timetable for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy n_r on notes for select to authenticated using (course_id=public.my_course() or public.is_staff());
create policy n_w on notes for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy no_r on notices for select to authenticated using (course_id is null or course_id=public.my_course() or public.is_staff());
create policy no_w on notices for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy w_r on whatsapp_groups for select to authenticated using (course_id=public.my_course() or public.is_staff());
create policy w_w on whatsapp_groups for all to authenticated using (public.is_staff()) with check (public.is_staff());

create policy at_r on attendance for select to authenticated using (student_id=auth.uid() or public.is_staff());
create policy at_w on attendance for all to authenticated using (public.is_staff()) with check (public.is_staff());

create policy i_ins on ideas for insert to authenticated with check (student_id=auth.uid());
create policy i_r on ideas for select to authenticated using (student_id=auth.uid() or public.is_staff());

create policy l_ins on leave_requests for insert to authenticated with check (student_id=auth.uid() and status='pending');
create policy l_r on leave_requests for select to authenticated using (student_id=auth.uid() or public.is_staff());
create policy l_dec on leave_requests for update to authenticated using (public.is_staff()) with check (public.is_staff());

create policy al_r on audit_log for select to authenticated using (public.my_role()='admin');

-- Private storage bucket for note files (PDF/docs): read by authenticated, write by staff
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('notes','notes',false,10485760,array['application/pdf','image/png','image/jpeg']) on conflict do nothing;
create policy s_r on storage.objects for select to authenticated using (bucket_id='notes');
create policy s_w on storage.objects for insert to authenticated with check (bucket_id='notes' and public.is_staff());

-- Make first teacher/admin manually (after they sign up):
-- update profiles set role='teacher' where id='<USER-UUID>';
-- Dashboard checklist: Auth > enable email confirmation, min password 8, leaked-password protection, CAPTCHA;
-- NEVER put the service_role key in website code; use only the anon key.

-- Wanafunzi waone walimu (kwa WhatsApp)
create policy p_t on profiles for select to authenticated using (role in ('teacher','admin'));
